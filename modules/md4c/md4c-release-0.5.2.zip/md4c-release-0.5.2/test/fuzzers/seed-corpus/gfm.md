* [ ] unchecked
* [x] checked

 A | B | C
---|--:|:-:
aaa|bbb|ccc

~del~ ~~del~~

http://example.com www.example.com doe@example.com
